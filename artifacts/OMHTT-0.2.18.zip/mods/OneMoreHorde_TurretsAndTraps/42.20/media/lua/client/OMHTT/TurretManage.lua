if isClient() or isServer() then return end
require("ISUI/ISPanel")
require("ISUI/ISButton")
require("TimedActions/ISBaseTimedAction")
local T = require("OMHTT/Turret")
local M = require("OMHTT/TurretModules")
local D = require("OMHTT/Diagnostics")
local X = require("OMHTT/TurretTransfers")
local Slot = require("OMHTT/TurretSlot")
local Range = require("OMHTT/TurretRange")
local Search = require("OMHTT/TurretSearch")
local Panel = ISPanel:derive("OMHTTTurretPanel")
local OpenAction = ISBaseTimedAction:derive("OMHTTTurretOpenAction")
local active = {}

---@return nil
function Panel:close()
    for i = 1, #self.slots do self.slots[i]:hideTooltip(); self.slots[i]:clearDrag() end
    Range.focus(self.player:getPlayerNum(), "manage", self.object, false)
    active[self.player:getPlayerNum()] = nil
    self:removeFromUIManager()
    D.emit("turret-manage-close", {id = self.deviceId})
end

---@param count number Queued items
---@param reason string? Rejection
---@return nil
function Panel:feedback(count, reason)
    self.result = getText("UI_OMHTT_ManageQueued", count)
    self.reason = reason and getText("UI_OMHTT_Manage" .. reason) or ""
    self.nextRefresh = 0
end

---@param items table Exact items
---@param incoming boolean Into turret
---@param kind string Slot type
---@return nil
function Panel:transfer(items, incoming, kind)
    local count, reason = X.queue(self.player, self.object, items, incoming, kind)
    self:feedback(count, reason)
end

---@return nil
function Panel:unload()
    self:transfer(self.ammoSlot.items, false, "ammo")
end

---@return nil
function Panel:fire()
    local result = require("OMHTT/TurretWorld").fire(self.player, self.object)
    self.result, self.reason = getText("UI_OMHTT_Manage" .. result), ""
    self.nextRefresh = 0
end

---@return nil
function Panel:toggleAuto()
    local W = require("OMHTT/TurretWorld")
    if not W.near(self.player, self.object) then return end
    local state = T.state(self.object)
    state.automatic = state.automatic == false
    W.refresh(self.object)
    self.nextRefresh = 0
    D.emit("turret-auto-toggle", {id = state.id, enabled = state.automatic})
end

---@return nil
function Panel:changePriority()
    local W = require("OMHTT/TurretWorld")
    if not W.near(self.player, self.object) then return end
    local contents = T.contents(self.object:getContainer())
    if not contents.active.Filter then return end
    local state = T.state(self.object)
    local priority = M.profile(state, contents).priority
    for i = 1, #M.PRIORITIES do
        if priority == M.PRIORITIES[i] then
            state.priority = M.PRIORITIES[i % #M.PRIORITIES + 1]
            break
        end
    end
    W.refresh(self.object)
    self.nextRefresh = 0
    D.emit("turret-priority", {id = state.id, priority = state.priority})
end

---@param delta number Wheel direction
---@return boolean handled
function Panel:scrollModules(delta)
    self.moduleRow = math.max(0, math.min(self.rows - 2, self.moduleRow + (delta > 0 and 1 or -1)))
    self.nextRefresh = 0
    return true
end

---@param kind string Item kind
---@param label string Slot label
---@param x number Local X
---@param y number Local Y
---@param width number Width
---@return table slot
function Panel:addSlot(kind, label, x, y, width)
    local slot = Slot:new(self, kind, label, x, y, width, self.slotHeight)
    slot:initialise()
    self:addChild(slot)
    self.slots[#self.slots + 1] = slot
    return slot
end

---@return nil
function Panel:refresh()
    local W = require("OMHTT/TurretWorld")
    local storage = self.object:getContainer()
    local contents = T.contents(storage)
    local cycle, status = T.cycle(contents, getTimestampMs())
    local power = W.power(self.object, contents)
    if not power and contents.head then status = "NoPower" end
    if contents.head and contents.head:getCondition() <= 0 then status = "NoHead" end
    self.status = status
    local response = Search.results[self.object]
    if response and self.searchResponse ~= response then
        self.searchResponse = response
        self.result, self.reason = getText("UI_OMHTT_Manage" .. response.status), ""
    end
    local state = T.state(self.object)
    local profile = M.profile(state, contents)
    local stats = T.cycleConfig(contents)
    self.stats = stats
    self.autoButton:setTitle(getText(state.automatic == false and "UI_OMHTT_AutoOff" or "UI_OMHTT_AutoOn"))
    local automationAllowed = SandboxVars.OMHTurretsTraps.AutomationEnabled ~= false
    self.autoButton:setEnable(automationAllowed)
    if not automationAllowed then
        self.autoButton:setTitle(getText("UI_OMHTT_AutoDisabled"))
    end
    self.priorityButton:setTitle(getText("UI_OMHTT_Priority", getText("UI_OMHTT_Priority" .. profile.priority)))
    self.priorityButton:setEnable(contents.active.Filter ~= nil)
    local active = {}
    for name in pairs(M.CORE) do
        if contents.active[name] then
            active[#active + 1] = contents.active[name]
        end
    end
    self.moduleEffects = getText("UI_OMHTT_ActiveModules", #active, profile.cone)
    self.fireButton:setEnable(status == "Ready")
    self.unloadButton:setEnable(contents.ammo > 0)
    local capacity = stats.modules
    self.rows = math.max(2, math.ceil(math.max(contents.modules, capacity) / 5))
    self.moduleRow = math.min(self.moduleRow, self.rows - 2)
    for i = 1, #self.slots do self.slots[i].items = {} end
    for i = 1, 10 do
        local number = self.moduleRow * 5 + i
        local slot = self.moduleSlots[i]
        slot.disabled = number > capacity
        slot.label = getText("UI_OMHTT_ManageModule", number)
        if number > capacity then slot.label = getText("UI_OMHTT_ManageLocked") end
    end
    local items, modules = storage:getItems(), 0
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        local kind = T.kind(item)
        local slot = self.headSlot
        if kind == "battery" then slot = self.batterySlot end
        if kind == "ammo" then slot = self.ammoSlot end
        if kind == "capacity" then slot = self.capacitySlot end
        if kind == "module" then
            modules = modules + 1
            slot = self.moduleSlots[modules - self.moduleRow * 5]
        end
        if kind and slot then slot.items[#slot.items + 1] = item end
    end
    self.ammoSlot.label = getText("UI_OMHTT_ManageAmmo", contents.ammo, stats.ammo,
        cycle and cycle.loaded or 0, stats.magazine)
    local charge = getText("UI_OMHTT_None")
    if contents.battery then charge = tostring(math.floor(contents.battery:getCurrentUsesFloat() * 100)) .. "%" end
    self.batterySlot.label = getText("UI_OMHTT_ManageBattery", charge)
    self.capacitySlot.disabled = contents.capacities > 0
    self.moduleLabel = getText("UI_OMHTT_ManageModules", contents.modules, capacity)
    self.powerLabel = getText("UI_OMHTT_ManagePowerNone")
    if power then
        self.powerLabel = getText("UI_OMHTT_ManagePowerExternal")
        if power.kind == "battery" then self.powerLabel = getText("UI_OMHTT_ManagePowerBattery") end
        if power.kind == "disabled" then self.powerLabel = getText("UI_OMHTT_ManagePowerDisabled") end
    end
    local statKey = table.concat({stats.damage, stats.range, stats.reload, stats.cooldown, stats.ammo, stats.modules, stats.knockdown}, ":")
    if self.lastStatKey ~= statKey then
        D.emit("turret-effective-stats", {id = self.deviceId, damage = stats.damage, range = stats.range,
            reload = stats.reload, cooldown = stats.cooldown, ammoCapacity = stats.ammo, moduleCapacity = stats.modules,
            knockdown = stats.knockdown, autoloader = stats.autoloader})
        self.lastStatKey = statKey
    end
    if self.lastStatus ~= status then
        D.emit("turret-manage-status", {id = self.deviceId, status = status, ammo = contents.ammo,
            loaded = cycle and cycle.loaded or 0, modules = contents.modules, power = power and power.kind or "none"})
        self.lastStatus = status
    end
end

---@return nil
function Panel:prerender()
    if not require("OMHTT/TurretWorld").near(self.player, self.object) then self:close(); return end
    ISPanel.prerender(self)
    local now = getTimestampMs()
    if now >= self.nextRefresh then
        self.nextRefresh = now + 200
        self:refresh()
    end
    local h, y = self.lineHeight, self.detailsY
    self:drawText(getText("UI_OMHTT_Turret"), 12, 8, 1, 1, 1, 1, UIFont.Medium)
    self:drawText(getText("UI_OMHTT_ManageHint"), 12, self.titleHeight, 0.8, 0.8, 0.8, 1, UIFont.Small)
    local label = self.moduleLabel
    if self.rows > 2 then label = label .. " — " .. getText("UI_OMHTT_ManageScroll") end
    self:drawText(label, 12, self.modulesY, 1, 1, 1, 1, UIFont.Small)
    self:drawText(self.moduleEffects, 12, y, 0.8, 0.8, 0.8, 1, UIFont.Small)
    self:drawText(getText("UI_OMHTT_Manage" .. self.status) .. " | " .. self.powerLabel, 12, y + h, 1, 1, 1, 1, UIFont.Small)
    local stats = self.stats
    self:drawText(getText("UI_OMHTT_ManageStats", string.format("%.1f", stats.damage), string.format("%.1f", stats.range),
        self.object:getHealth(), self.object:getMaxHealth()), 12, y + h * 2, 1, 1, 1, 1, UIFont.Small)
    self:drawText(getText("UI_OMHTT_ManageTiming", string.format("%.2f", stats.reload / 1000), string.format("%.2f", 1000 / stats.cooldown)),
        12, y + h * 3, 1, 1, 1, 1, UIFont.Small)
    local message = self.result .. ":" .. self.reason
    if self.lastMessage ~= message then
        self.lastMessage, self.messageAt = message, now
    end
    local elapsed = now - self.messageAt
    local glow = 0
    if elapsed < 1500 then glow = (1 - elapsed / 1500) * (0.5 + 0.5 * math.cos(elapsed / 120)) end
    self:drawText(self.result, 12, y + h * 4, 0.9 + glow * 0.1, 0.85 + glow * 0.15, 0.65 + glow * 0.35, 1, UIFont.Small)
    self:drawText(self.reason, 12, y + h * 5, 0.9 + glow * 0.1, 0.85 + glow * 0.15, 0.65 + glow * 0.35, 1, UIFont.Small)
end

---@param x number Local X
---@param y number Local Y
---@return boolean handled
function Panel:onMouseDown(x, y)
    if y < self.titleHeight then ISPanel.onMouseDown(self, x, y) end
    return true
end

---@return nil
function OpenAction:perform()
    if require("OMHTT/TurretWorld").near(self.character, self.object) then
        local index = self.character:getPlayerNum()
        if active[index] then active[index]:close() end
        local font = getTextManager()
        local lineHeight = font:getFontHeight(UIFont.Small) + 3
        local titleHeight = font:getFontHeight(UIFont.Medium) + 16
        local width = math.min(getPlayerScreenWidth(index) - 24, math.max(600, lineHeight * 29))
        local slotHeight = lineHeight + 48
        local top = titleHeight + lineHeight + 12
        local modulesY = top + (slotHeight + 8) * 2
        local moduleHeight = lineHeight * 2 + 24
        local detailsY = modulesY + lineHeight + (moduleHeight + 6) * 2 + 6
        local height = detailsY + lineHeight * 6 + 82
        local x = getPlayerScreenLeft(index) + getPlayerScreenWidth(index) - width - 12
        local y = getPlayerScreenTop(index) + math.max(12, (getPlayerScreenHeight(index) - height) / 2)
        local panel = Panel:new(x, y, width, height)
        panel.player, panel.object, panel.nextRefresh = self.character, self.object, 0
        panel.deviceId, panel.slots, panel.moduleSlots = T.state(self.object).id, {}, {}
        panel.moduleRow, panel.rows = 0, 2
        panel.lineHeight, panel.titleHeight, panel.slotHeight = lineHeight, titleHeight, slotHeight
        panel.modulesY, panel.detailsY, panel.result, panel.reason = modulesY, detailsY, "", ""
        panel.moveWithMouse = true
        panel.backgroundColor = {r = 0.04, g = 0.04, b = 0.04, a = 0.96}
        panel:initialise()
        panel.headSlot = panel:addSlot("head", getText("UI_OMHTT_ManageHead"), 12, top, (width - 32) / 2)
        panel.batterySlot = panel:addSlot("battery", "", width / 2 + 4, top, (width - 32) / 2)
        panel.ammoSlot = panel:addSlot("ammo", "", 12, top + slotHeight + 8, (width - 32) * 0.65)
        panel.capacitySlot = panel:addSlot("capacity", getText("UI_OMHTT_ManageCapacity"), 20 + (width - 32) * 0.65, top + slotHeight + 8, (width - 32) * 0.35)
        local moduleWidth = (width - 48) / 5
        for i = 1, 10 do
            panel.moduleSlots[i] = panel:addSlot("module", "", 12 + ((i - 1) % 5) * (moduleWidth + 6),
                modulesY + lineHeight + math.floor((i - 1) / 5) * (moduleHeight + 6), moduleWidth)
            panel.moduleSlots[i]:setHeight(moduleHeight)
        end
        panel.autoButton = ISButton:new(12, height - 72, 150, 28, "", panel, Panel.toggleAuto)
        panel.priorityButton = ISButton:new(170, height - 72, width - 182, 28, "", panel, Panel.changePriority)
        panel.fireButton = ISButton:new(12, height - 38, 110, 28, getText("UI_OMHTT_ManageFire"), panel, Panel.fire)
        panel.unloadButton = ISButton:new(130, height - 38, 150, 28, getText("UI_OMHTT_ManageUnload"), panel, Panel.unload)
        local close = ISButton:new(width - 34, 6, 26, 24, "X", panel, Panel.close)
        local buttons = {panel.fireButton, panel.unloadButton, panel.autoButton, panel.priorityButton, close}
        for i = 1, #buttons do buttons[i]:initialise(); panel:addChild(buttons[i]) end
        panel:refresh()
        panel:addToUIManager()
        active[index] = panel
        Range.focus(index, "manage", self.object, true)
        D.emit("turret-manage-open", {id = panel.deviceId, interface = "dedicated", width = width, height = height})
    end
    ISBaseTimedAction.perform(self)
end

---@return boolean valid
function OpenAction:isValid()
    return require("OMHTT/TurretWorld").near(self.character, self.object)
end

---@param player IsoPlayer Operator
---@param object IsoObject Exact turret
---@return table action
function OpenAction:new(player, object)
    local action = ISBaseTimedAction.new(self, player)
    action.object, action.maxTime = object, 1
    return action
end

---@param object IsoObject Exact turret
---@param player IsoPlayer Operator
---@return nil
local function open(object, player)
    if luautils.walkAdjObject(player, object, false) then ISTimedActionQueue.add(OpenAction:new(player, object)) end
end

return open

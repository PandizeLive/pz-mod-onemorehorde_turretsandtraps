@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Install-Foundation.ps1"
if errorlevel 1 echo Installation failed. Read the error above; no test is ready until it is resolved.
pause

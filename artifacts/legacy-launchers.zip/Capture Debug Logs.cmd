@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Capture-Diagnostics.ps1"
pause

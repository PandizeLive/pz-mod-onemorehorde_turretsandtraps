if isServer() then return end

local Foundation = require("OMHTT/Foundation")
require("ISUI/ISContextMenu")
require("ISUI/ISModalRichText")

local snapshots = {}
local lastChanges = {}
local serial = 0
local dialog = nil

---@param player IsoPlayer Local player
---@param command string Requested action
---@param args table Request payload
---@return nil
local function dispatch(player, command, args)
    if isClient() then
        sendClientCommand(player, Foundation.MODULE, command, args)
    elseif isServer() then
        error("[OMHTT] Client dispatch attempted on server")
    else
        local Server = require("OMHTT/FoundationServer")
        Server.onCommand(Foundation.MODULE, command, player, args)
    end
end

---@param target table Captured tile and local player
---@param command string Requested action
---@return nil
local function request(target, command)
    local player = getSpecificPlayer(target.playerNum)
    if not Foundation.canUse(player) then return end
    serial = serial + 1
    local args = {
        version = Foundation.VERSION, request = serial,
        x = target.x, y = target.y, z = target.z,
        epoch = 0, id = "", revision = 0,
    }
    local snapshot = snapshots[target.playerNum]
    if snapshot and snapshot.x == target.x and snapshot.y == target.y and snapshot.z == target.z then
        args.epoch = snapshot.epoch
        args.id = snapshot.id
        args.revision = snapshot.revision
    end
    if command == "Condition" then
        args.condition = 37
    end
    if command ~= "Inspect" then
        lastChanges[target.playerNum] = {command = command, args = args}
    end
    dispatch(player, command, args)
end

---@param target table Captured player
---@return nil
local function replay(target)
    local last = lastChanges[target.playerNum]
    if not last then return end
    local args = {}
    for key, value in pairs(last.args) do
        args[key] = value
    end
    serial = serial + 1
    args.request = serial
    dispatch(getSpecificPlayer(target.playerNum), last.command, args)
end

---@param playerNum number Local player index
---@param context ISContextMenu Context menu
---@param worldobjects table Clicked objects
---@param test boolean Menu probe
---@return boolean? available
local function fillMenu(playerNum, context, worldobjects, test)
    local player = getSpecificPlayer(playerNum)
    if not Foundation.canUse(player) or #worldobjects == 0 then return end
    local square = worldobjects[1]:getSquare()
    if not square then return end
    if test then return true end
    local target = {playerNum = playerNum, x = square:getX(), y = square:getY(), z = square:getZ()}
    local root = context:addOption(getText("ContextMenu_OMHTT_Foundation", Foundation.VERSION), nil, nil)
    local menu = ISContextMenu:getNew(context)
    context:addSubMenu(root, menu)
    menu:addOption(getText("ContextMenu_OMHTT_Inspect"), target, request, "Inspect")
    menu:addOption(getText("ContextMenu_OMHTT_Place"), target, request, "Place")
    local snapshot = snapshots[playerNum]
    if snapshot and snapshot.x == target.x and snapshot.y == target.y and snapshot.z == target.z and snapshot.id ~= "" then
        menu:addOption(getText("ContextMenu_OMHTT_Condition"), target, request, "Condition")
        menu:addOption(getText("ContextMenu_OMHTT_Remove"), target, request, "Remove")
    end
    if lastChanges[playerNum] then
        menu:addOption(getText("ContextMenu_OMHTT_Replay"), target, replay)
    end
end

---@param module string Server namespace
---@param command string Server command
---@param result table Authoritative tile snapshot
---@return nil
local function onResult(module, command, result)
    if module ~= Foundation.MODULE or command ~= "Result" then return end
    local previous = snapshots[result.playerNum]
    if previous and previous.request > result.request then return end
    snapshots[result.playerNum] = result
    local localCount = 0
    local localCondition = -1
    local localRevision = 0
    local square = getCell():getGridSquare(result.x, result.y, result.z)
    if square and result.id ~= "" then
        local object, count = Foundation.find(square, result.id)
        localCount = count
        if count == 1 then
            local marker = object:getModData().OMHTT
            localCondition = marker.condition
            localRevision = marker.revision
        end
    elseif square then
        localCount = Foundation.countPrototypes(square)
    end
    local agreement = "Waiting"
    if square and localCount == result.count and localCondition == result.condition and localRevision == result.revision then
        agreement = "Agrees"
    end
    local text = getText("UI_OMHTT_Header", Foundation.VERSION, result.version, result.game)
        .. " <LINE> " .. getText("UI_OMHTT_" .. result.status)
        .. " <LINE> " .. getText("UI_OMHTT_Tile", result.x, result.y, result.z)
        .. " <LINE> " .. getText("UI_OMHTT_State", result.id, result.condition, result.revision, result.count)
        .. " <LINE> " .. getText("UI_OMHTT_Local", localCondition, localRevision, localCount)
        .. " <LINE> " .. getText("UI_OMHTT_" .. agreement)
    print("[OMHTT] client-result status=" .. result.status .. " id=" .. result.id
        .. " serverCondition=" .. result.condition .. " localCondition=" .. localCondition
        .. " serverCount=" .. result.count .. " localCount=" .. localCount .. " agreement=" .. agreement)
    if dialog then
        dialog:removeFromUIManager()
    end
    dialog = ISModalRichText:new(getCore():getScreenWidth() / 2 - 300,
        getCore():getScreenHeight() / 2 - 160, 600, 320, text, false)
    dialog:initialise()
    dialog:addToUIManager()
end

---@return nil
local function onStart()
    snapshots = {}
    lastChanges = {}
    serial = 0
    print("[OMHTT] client-ready version=" .. Foundation.VERSION .. " game=" .. getCore():getVersionNumber())
end

Events.OnFillWorldObjectContextMenu.Add(fillMenu)
Events.OnServerCommand.Add(onResult)
Events.OnGameStart.Add(onStart)

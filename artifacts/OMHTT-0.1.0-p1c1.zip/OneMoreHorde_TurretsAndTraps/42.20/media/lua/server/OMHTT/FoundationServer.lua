if isClient() then return end

local Foundation = require("OMHTT/Foundation")

---@class OMHTTFoundationServer
local Server = {}
local store = nil

---@return nil
function Server.initialize()
    store = ModData.getOrCreate(Foundation.STORE)
    if store.schema == nil then
        store.schema = 1
        store.nextId = 1
        store.tileCount = 0
        store.tiles = {}
    end
    if store.schema ~= 1 or type(store.tiles) ~= "table" then
        error("[OMHTT] Unsupported foundation save schema; refusing mutations")
    end
    print("[OMHTT] server-ready version=" .. Foundation.VERSION .. " game=" .. getCore():getVersionNumber())
end

---@param object IsoObject Exact device object
---@param record table Authoritative device state
---@return nil
local function writeMarker(object, record)
    object:getModData().OMHTT = {
        schema = 1,
        id = record.id,
        condition = record.condition,
        revision = record.revision,
        testOwner = record.testOwner,
    }
end

---@param player IsoPlayer Requesting player
---@param command string Command name
---@param args table Request arguments
---@param status string Translation suffix
---@param square IsoGridSquare? Requested loaded tile
---@param slot table? Persistent tile slot
---@return nil
local function reply(player, command, args, status, square, slot)
    local result = {
        version = Foundation.VERSION,
        game = getCore():getVersionNumber(),
        command = command,
        request = args.request,
        status = status,
        playerNum = player:getPlayerNum(),
        x = args.x, y = args.y, z = args.z,
        epoch = 0,
        id = "", condition = -1, revision = 0, count = 0,
    }
    if slot then
        result.epoch = slot.epoch
        if slot.device then
            local record = slot.device
            result.id = record.id
            result.condition = record.condition
            result.revision = record.revision
            if square then
                local object, count = Foundation.find(square, record.id)
                result.count = count
            end
        end
    end
    print("[OMHTT] command=" .. command .. " status=" .. status .. " id=" .. result.id
        .. " condition=" .. result.condition .. " revision=" .. result.revision
        .. " count=" .. result.count .. " tile=" .. Foundation.key(args.x, args.y, args.z))
    if isClient() then
        error("[OMHTT] Server reply attempted on client")
    elseif isServer() then
        sendServerCommand(player, Foundation.MODULE, "Result", result)
    else
        triggerEvent("OnServerCommand", Foundation.MODULE, "Result", result)
    end
end

---@param square IsoGridSquare Loaded tile
---@param reason string? Reconciliation origin; omitted by the engine load event
---@return nil
function Server.reconcile(square, reason)
    if not store then return end
    if reason == nil then
        reason = "load"
    end
    local slot = store.tiles[Foundation.key(square:getX(), square:getY(), square:getZ())]
    if not slot or not slot.device then return end
    local record = slot.device
    local object, count = Foundation.find(square, record.id)
    if count ~= 1 then
        print("[OMHTT] reconcile-conflict id=" .. record.id .. " matches=" .. count .. "; preserved without respawn")
        return
    end
    local marker = object:getModData().OMHTT
    if marker.condition ~= record.condition or marker.revision ~= record.revision or marker.testOwner ~= record.testOwner then
        writeMarker(object, record)
        object:transmitModData()
    end
    print("[OMHTT] reconciled origin=" .. reason .. " id=" .. record.id .. " condition=" .. record.condition .. " revision=" .. record.revision)
end

---@param object IsoObject Object being removed by the engine
---@return nil
function Server.onRemoved(object)
    if not store then return end
    local square = object:getSquare()
    if not square then return end
    local slot = store.tiles[Foundation.key(square:getX(), square:getY(), square:getZ())]
    if not slot or not slot.device or not Foundation.matches(object, slot.device.id) then return end
    print("[OMHTT] retired id=" .. slot.device.id)
    slot.device = nil
    slot.epoch = slot.epoch + 1
end

---@param module string Command namespace
---@param command string Requested action
---@param player IsoPlayer Engine-bound sender
---@param args table? Serializable request
---@return nil
function Server.onCommand(module, command, player, args)
    if module ~= Foundation.MODULE then return end
    if command ~= "Inspect" and command ~= "Place" and command ~= "Condition" and command ~= "Remove" then return end
    if not store or not player or type(args) ~= "table" then return end
    if not Foundation.isInteger(args.x, 0, 1000000) or not Foundation.isInteger(args.y, 0, 1000000)
        or not Foundation.isInteger(args.z, -32, 31) or not Foundation.isInteger(args.request, 1, 1000000000) then return end
    if not Foundation.canUse(player) then
        reply(player, command, args, "Denied")
        return
    end
    if args.version ~= Foundation.VERSION then
        reply(player, command, args, "VersionMismatch")
        return
    end
    if math.floor(player:getZ()) ~= args.z or math.abs(player:getX() - args.x - 0.5) > 2
        or math.abs(player:getY() - args.y - 0.5) > 2 then
        reply(player, command, args, "TooFar")
        return
    end
    local square = getCell():getGridSquare(args.x, args.y, args.z)
    if not square or not square:getFloor() then
        reply(player, command, args, "Unavailable")
        return
    end
    local key = Foundation.key(args.x, args.y, args.z)
    local slot = store.tiles[key]
    if command == "Inspect" then
        Server.reconcile(square, "inspect")
        reply(player, command, args, "Inspected", square, slot)
        return
    end
    local epoch = 0
    if slot then
        epoch = slot.epoch
    end
    if args.epoch ~= epoch then
        reply(player, command, args, "Stale", square, slot)
        return
    end
    if command == "Place" then
        if (slot and slot.device) or Foundation.countPrototypes(square) > 0 then
            reply(player, command, args, "Occupied", square, slot)
            return
        end
        if not square:isFree(false) then
            reply(player, command, args, "Blocked", square, slot)
            return
        end
        if not slot then
            if store.tileCount >= Foundation.MAX_TILES then
                reply(player, command, args, "Limit", square)
                return
            end
            slot = {epoch = 0}
            store.tiles[key] = slot
            store.tileCount = store.tileCount + 1
        end
        local record = {
            id = "test-" .. tostring(store.nextId),
            condition = 100,
            revision = 1,
            testOwner = player:getUsername(),
        }
        store.nextId = store.nextId + 1
        local object = IsoObject.new(square, Foundation.SPRITE, Foundation.PREFIX .. record.id)
        object:setOutlineOnMouseover(true)
        writeMarker(object, record)
        square:AddTileObject(object)
        slot.device = record
        slot.epoch = slot.epoch + 1
        object:transmitCompleteItemToClients()
        reply(player, command, args, "Placed", square, slot)
        return
    end
    local record = slot and slot.device
    if not record or args.id ~= record.id or args.revision ~= record.revision then
        reply(player, command, args, "Stale", square, slot)
        return
    end
    local object, count = Foundation.find(square, record.id)
    if count ~= 1 then
        reply(player, command, args, "Conflict", square, slot)
        return
    end
    if command == "Condition" then
        if args.condition ~= 37 then return end
        record.condition = 37
        record.revision = record.revision + 1
        slot.epoch = slot.epoch + 1
        writeMarker(object, record)
        object:transmitModData()
        reply(player, command, args, "Changed", square, slot)
    elseif command == "Remove" then
        square:transmitRemoveItemFromSquare(object)
        if object:getObjectIndex() ~= -1 then
            reply(player, command, args, "Conflict", square, slot)
            return
        end
        if slot.device then
            slot.device = nil
            slot.epoch = slot.epoch + 1
        end
        reply(player, command, args, "Removed", square, slot)
    end
end

Events.OnInitGlobalModData.Add(Server.initialize)
Events.LoadGridsquare.Add(Server.reconcile)
Events.OnObjectAboutToBeRemoved.Add(Server.onRemoved)
Events.OnClientCommand.Add(Server.onCommand)

return Server

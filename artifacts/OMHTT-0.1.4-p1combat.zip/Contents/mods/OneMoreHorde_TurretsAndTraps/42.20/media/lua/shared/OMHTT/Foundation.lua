---@class OMHTTFoundation
local Foundation = {
    VERSION = "0.1.4-p1combat",
    MODULE = "OMHTT_Foundation",
    STORE = "OMHTT_Foundation_v1",
    PREFIX = "OMHTT_P1C1_",
    SPRITE = "media/textures/OMHTT_TestCube.png",
    MAX_TILES = 64,
}

---@param facing number Signed heading index
---@return number normalized Integer heading in 0-15
---@nodiscard
function Foundation.normalizeFacing(facing)
    local index = math.floor(facing)
    return index - math.floor(index / 16) * 16
end

---@param kind string Prototype kind
---@param facing number Sixteen-step heading
---@return string path Technical sprite path
---@nodiscard
function Foundation.spriteFor(kind, facing)
    facing = Foundation.normalizeFacing(facing)
    if kind == "barrier" then
        return "media/textures/OMHTT_Barrier" .. math.floor(facing / 4) % 4 .. ".png"
    elseif kind == "potato" then
        return "media/textures/OMHTT_Aim" .. facing % 16 .. ".png"
    end
    return "media/textures/OMHTT_Foundation.png"
end

---@param value any Candidate integer
---@param minimum number Inclusive lower bound
---@param maximum number Inclusive upper bound
---@return boolean valid
---@nodiscard
function Foundation.isInteger(value, minimum, maximum)
    return type(value) == "number" and value >= minimum and value <= maximum and value == math.floor(value)
end

---@param x number Tile X
---@param y number Tile Y
---@param z number Tile Z
---@return string key
---@nodiscard
function Foundation.key(x, y, z)
    return tostring(x) .. ":" .. tostring(y) .. ":" .. tostring(z)
end

---@param player IsoPlayer Requesting player
---@return boolean allowed
---@nodiscard
function Foundation.canUse(player)
    if not player or player:isDead() then return false end
    if not SandboxVars.OMHTurretsTraps or SandboxVars.OMHTurretsTraps.FoundationTestControls ~= true then return false end
    if isClient() then
        return player:getRole():hasCapability(Capability.UseDebugContextMenu)
    elseif isServer() then
        return player:getRole():hasCapability(Capability.UseDebugContextMenu)
    else
        return true
    end
end

---@param object IsoObject World object
---@param id string Expected device identity
---@return boolean matches
---@nodiscard
function Foundation.matches(object, id)
    if object:getName() ~= Foundation.PREFIX .. id or not object:hasModData() then return false end
    local marker = object:getModData().OMHTT
    return type(marker) == "table" and marker.id == id and marker.schema == 1
end

---@param square IsoGridSquare Loaded tile
---@param id string Device identity
---@return IsoObject? object
---@return number count
---@nodiscard
function Foundation.find(square, id)
    local found = nil
    local count = 0
    local objects = square:getObjects()
    for i = 0, objects:size() - 1 do
        local object = objects:get(i)
        if Foundation.matches(object, id) then
            found = object
            count = count + 1
        end
    end
    return found, count
end

---@param square IsoGridSquare Loaded tile
---@return number count
---@nodiscard
function Foundation.countPrototypes(square)
    local count = 0
    local objects = square:getObjects()
    for i = 0, objects:size() - 1 do
        local name = objects:get(i):getName()
        if type(name) == "string" and string.sub(name, 1, #Foundation.PREFIX) == Foundation.PREFIX then
            count = count + 1
        end
    end
    return count
end

return Foundation

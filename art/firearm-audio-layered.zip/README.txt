Local audition set. Current installed native events, filtered plus the owner's unfiltered overlay.
Mono 48kHz OGG Vorbis quality 4. Includes 18 firearm events and 2 cap-gun events.
Family recommendations reuse these files; no duplicated family files. Not an installable mod.
